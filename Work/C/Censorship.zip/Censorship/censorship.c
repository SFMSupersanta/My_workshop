#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define MAX_CEN_WORD 100
#define STRING_SIZE 255

void clear_buffer()
{
    while(getchar() != '\n');
}

int is_equal(char* str, char* cmp)
{
    for(int i = 0; i < strlen(cmp); i++)
    {
        if(*(str + i) != *(cmp + i)) return 0;
    }
    return 1;
}

char* inclement_to(char* str, char* censored)
{

}

int from_file(char* filename, char buffer[MAX_CEN_WORD][STRING_SIZE])
{
    int count = 0;
    FILE *fp = fopen(filename, "r");
    if(fp == NULL) 
    {
        printf("Could not open %s\n", filename);
        return 0;
    }
    
    char buf[STRING_SIZE];
    while(fgets(buf, STRING_SIZE, fp) != NULL)
    {
        strncpy(*buffer, buf, STRING_SIZE);
        buffer[0][strcspn(buffer[0], "\n")] = '\0';
        if(strlen(*buffer++) != 0)count++;

    }

    fclose(fp);
    return count;
}

void to_file(char* filename, char buffer[MAX_CEN_WORD][STRING_SIZE], int cen_size)
{
    FILE *fp = fopen(filename, "w");
    if(fp == NULL) 
    {
        printf("Could not open %s", filename);
        return;
    }
    for(int i = 0; i < cen_size; i++)
    {
        fprintf(fp, "%s\n", *buffer);
        *buffer++;
    }
    fclose(fp);
}

long long getInt(char msg[], long long min, long long max)
{ 

    char val[20];           //input value
    long long intval;
    int count,rc;      //int value and count value
    while(1)
    {
        printf("%s", msg);
        count = 0;
        rc = 0;
        fgets(val,20,stdin);
        if(val[0]!='\n')
        {
            if(0<=max&&0>=min) if(val[0]=='0' && val[1] == '\n') return 0;
            for(int i=0; i< 20; i++) 
            {
                if(val[i]=='\n') 
                {
                    rc = 1;
                    i=20;
                }
            } 
            if(rc==0) 
            {
                clear_buffer();
            }
            val[strcspn(val,"\n")] = '\0';
            
            if(val[count]=='0') 
            {
                while(val[count]=='0')
                {
                    count++;
                }
            }             
            char *ovf;
            intval = strtoll(val,&ovf,10);
            
            if(intval<=0) count++;
            long long intvaldup = intval;

            while(intvaldup!=0)
            {
                intvaldup/=10;
                count++;
            }
            if (val[count] != '\0')  printf("*Trailing Character(s)*\n");
            else if(min<=intval&&intval<=max)
            {
                return intval;
            }else printf("*OUT OF RANGE*\n");
        } else printf("*No input*\n");
    }
}

void add_word(char cen_word[MAX_CEN_WORD][STRING_SIZE], int* cen_size)
{
    puts("Input the new word: ");
    fgets(*(cen_word + *cen_size),STRING_SIZE,stdin);
    cen_word[*cen_size][strcspn(cen_word[*cen_size],"\n")] = '\0';
    *cen_size = *cen_size + 1;
}

void display_list(char cen_word[MAX_CEN_WORD][STRING_SIZE], int cen_size)
{
    puts("Censor list: ");
    for(int i=0; i<cen_size; i++)
        puts(cen_word[i]);
}

char *str_replace(char *orig, char *rep, char *with) {
    char *result; // the return string
    char *ins;    // the next insert point
    char *tmp;    // varies
    int len_rep;  // length of rep (the string to remove)
    int len_with; // length of with (the string to replace rep with)
    int len_front; // distance between rep and end of last rep
    int count;    // number of replacements

    // sanity checks and initialization
    if (!orig || !rep)
        return NULL;
    len_rep = strlen(rep);
    if (len_rep == 0)
        return NULL; // empty rep causes infinite loop during count
    if (!with)
        with = "";
    len_with = strlen(with);

    // count the number of replacements needed
    ins = orig;
    for (count = 0; tmp = strstr(ins, rep); ++count) {
        ins = tmp + len_rep;
    }

    tmp = result = malloc(strlen(orig) + (len_with - len_rep) * count + 1);

    if (!result)
        return NULL;

    // first time through the loop, all the variable are set correctly
    // from here on,
    //    tmp points to the end of the result string
    //    ins points to the next occurrence of rep in orig
    //    orig points to the remainder of orig after "end of rep"
    while (count--) {
        ins = strstr(orig, rep);
        len_front = ins - orig;
        tmp = strncpy(tmp, orig, len_front) + len_front;
        tmp = strcpy(tmp, with) + len_with;
        orig += len_front + len_rep; // move to next "end of rep"
    }
    strcpy(tmp, orig);
    return result;
}

void into_cen(int size, char dest[MAX_CEN_WORD][STRING_SIZE], char src[MAX_CEN_WORD][STRING_SIZE])
{
    for(int i = 0; i < size; i++) {
        char buffs[STRING_SIZE];
        strcpy(buffs, src[i]);
        strset(buffs + 1, '*');
        strcpy(dest[i], buffs);
    }
}

void censor(char cen_word[MAX_CEN_WORD][STRING_SIZE], int cen_size)
{
    char cen_af[MAX_CEN_WORD][STRING_SIZE];
    into_cen(cen_size, cen_af, cen_word);
    char input[STRING_SIZE];
    printf("Input a string: ");
    fgets(input, STRING_SIZE, stdin);
    input[strcspn(input, "\n")] = '\0';

    for(int i = 0; i < cen_size; ++i)
    {
        char* buf = str_replace(input, cen_word[i], cen_af[i]);
        strcpy(input, buf);
        if(buf != NULL) free(buf);
    }
    printf("Cencored string: %s\n", input);
}

int main()
{
    char cen_word[MAX_CEN_WORD][STRING_SIZE];
    int cen_size = from_file("data.txt", cen_word);
    printf("Censor words: %d\n", cen_size);

    int choice;

    do{
        printf("1. Add censor word\n");
        printf("2. Display list\n");
        printf("3. Censor inputed string\n");
        choice = getInt("Your choice? ", 0, 3);
        switch(choice){
            case 1:
                add_word(cen_word, &cen_size);
                to_file("data.txt", cen_word, cen_size);
                break;
            case 2:
                display_list(cen_word, cen_size);
                break;
            case 3:
                censor(cen_word, cen_size);
                break;
            default: printf("Closing the program");
        }
    }while(choice != 0);
}

/**
 * @brief Hãy viết 1 chương trình C gồm các menu sau

1. Thêm từ nóng, từ nhạy cảm vào từ điển các từ nhạy cảm
2. Hiển thị danh sách từ nóng, từ nhạy cảm hiện tại
3. Nhập chuỗi và hiển thị chuỗi sau khi che các từ nhạy cảm

0. Thoát chương trình

Yêu cầu chức năng: 
1. Khi thêm từ nóng, từ nhạy cảm cần lưu từ đó xuống file lưu trữ để lần mở app sau sẽ load lại được danh sách từ đã thêm trước đó
2. Hiển thị toàn bộ các từ nóng, từ nhạy cảm trong danh sách.
3.  Ví dụ trong từ điển đang định nghĩa các từ sau là từ nóng: fuck, hell, shit
Người dùng nhập chuỗi : "What the hell, suck the fuck up, don't do that shit"
Thì chuỗi được in ra là:     "What the H***, suck the F*** up, don't do that S***"


Lưu ý: từ nhạy cảm không phân biệt hoa thường, khi che từ thì viết hoa chữ cái đầu và số lượng dấu * sẽ tương ứng số lượng chữ cái sau chữ cái đầu tiên
 * 
 */