#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define WIN_PRICE 10.0
#define SECOND_PRICE 0.50
#define BUFFER_SIZE 32

int radig()
{
    return (rand() % 10);
}

double readfile()
{
    FILE *file = NULL;
    file = fopen("data.txt", "r+");
    if(file != NULL)
    {
        char buf[BUFFER_SIZE];
        fgets (buf, BUFFER_SIZE, file);
        fclose(file);
        if(atof(buf) != 0.0) return atof(buf);
        printf("Error reading data");
    } 
    else 
    {
        printf("Error opening file\nUsing default (10$)\n");
        fclose(file);
        return 10.0;
    }
}



void tofile(double value)   
{
    FILE *file = NULL;
    file = fopen("data.txt", "w");
    if(file != NULL)
    {
        fprintf(file, "%.2lf", value);
        fclose(file);
    }
    else 
    {
        printf("Error opening file\nStoring default (10$)\n");
        fprintf(file, "%.2lf", 10.0);
        fclose(file);
    }
}

void play(double *cash)
{
    int a = radig(), b = radig(), c = radig();
    printf("The slot machine shows %d%d%d\n", a, b, c);
    if(a == b && a == c) 
    {
        printf("You win the big price, $10.00!\n");
        *cash += 9.75;
        printf("You have $%.2lf.\n", *cash);
    }
    else if(a == b || b == c || a == c)
    {
        printf("You win 50 cents!\n");
        *cash += 0.25;
        printf("You have $%.2lf.\n", *cash);
    }
    else 
    {
        printf("Sorry you don't win anything\n");
        *cash -= 0.25;
        printf("You have $%.2lf.\n", *cash);
    }
    if (*cash == 0.0) 
    {
        printf("The game ended, you have no money left.");
        tofile(10.0);
        exit(0);
    }
}

void save(double cash)
{
    printf("Saved your cash to data.txt\n");
    tofile(cash);
}

void cash_out(double cash)
{
    printf("Thank you for playing! You end with $%.2lf!", cash);
    tofile(10.0);
}

int main()
{
    double cash = readfile();
    srand(time(NULL));
    int choice;
    do
    {
        puts("1) Play the slot machine");
        puts("2) Save game");
        puts("3) Cash out");
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
                play(&cash);
                break;
            case 2:
                save(cash);
                break;
            case 3:
                cash_out(cash);
        }
    } while (choice != 3);
}