
package assignment;

import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class Assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                int choice;
        StudentOperations student = new StudentOperations();
        ArrayList<String> choices = new ArrayList<>();
        choices.add("1. Add n student to the list ");
        choices.add("2. Print out the list");
        choices.add("3. Add a student to the list");
        choices.add("4. Find by id number");
        choices.add("5. Delete from the list");
        choices.add("6. Calculate the average Marks 10% Progress test + 10% Assignment + 10% Workshop + 40% Practical Exam + 30% Final exam");
        choices.add("7. Find if student Passed or not");
        choices.add("8. print to file");
        do {
            choices.forEach((string) -> {
                System.out.println(string);
                    });
            choice = Vali.nextInt("Your choice? (0 to exit)", 0, 8);
            switch (choice) {
                case 1 :
                    student.addMultiple();
                    break;
                case 2 :
                    student.printList();
                    break;
                case 3 :  
                    student.addStudent();
                    break;
                case 4 :
                    student.findID();
                    break;
                case 5 :
                    student.deleteID();
                    break;
                case 6 :
                    student.printResults();
                    break;
                case 7 :
                    student.printPassed();
                    break;
                case 8 :
                    student.toFile();
                    break;
                case 0 :
                    System.out.println("Exiting");
                    break;
            }
        } while (choice != 0);
    }
    
}
