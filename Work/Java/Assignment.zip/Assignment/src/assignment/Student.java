/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author Admin
 */
public class Student {
        private String id;
    private String fullName;
    private String sex;
    private double progressT;
    private double assignments;
    private double workShop;
    private double practicalExam;
    private double finalExam;
    
    public Student(String id, String fullName, String Sex, double progressT, double assignments, double workShop, double practicalExam, double finalExam) {
        this.setId(id);
        this.setFullName(fullName);
        this.setSex(Sex);
        this.setProgressT(progressT);
        this.setAssignments(assignments);
        this.setWorkShop(workShop);
        this.setPracticalExam(practicalExam);
        this.setFinalExam(finalExam);
    }
    
    public double getResult() {
        return 0.1*(getProgressT() + getAssignments() + getWorkShop()) + 0.4 * (getPracticalExam()) + 0.3 * (getFinalExam());
    }
    
    public boolean isPassed() {
        return !(getResult() < 5) && getProgressT() != 0 && getAssignments() != 0 && getWorkShop() != 0 && getPracticalExam() != 0 && !(getFinalExam() < 4);
    }

    public String toString() {
        return String.format("||%6s||%-30s||%6s||%5.2f||%5.2f||%5.2f||%5.2f||%5.2f||", getId(), getFullName(), getSex(), getProgressT(), getAssignments(), getWorkShop(), getPracticalExam(), getFinalExam());
    }

    public String toStringPassed()
    {
        return String.format("||%6s||%-30s||%6s||%20s||", getId(), getFullName(), getSex(), isPassed()? "passed" : "failed");
    }

    public String toStringResult()
    {
        return String.format("||%6s||%-30s||%6s||%20f||", getId(), getFullName(), getSex(), getResult());
    }


    public static void main(String[] args)
    {
        Student student2 = new Student("176209", "abc", "Male", 10,10,10,10,10);
        System.out.println(student2);
        System.out.println(student2.toStringPassed());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public double getProgressT() {
        return progressT;
    }

    public void setProgressT(double progressT) {
        this.progressT = progressT;
    }

    public double getAssignments() {
        return assignments;
    }

    public void setAssignments(double assignments) {
        this.assignments = assignments;
    }

    public double getWorkShop() {
        return workShop;
    }

    public void setWorkShop(double workShop) {
        this.workShop = workShop;
    }

    public double getPracticalExam() {
        return practicalExam;
    }

    public void setPracticalExam(double practicalExam) {
        this.practicalExam = practicalExam;
    }

    public double getFinalExam() {
        return finalExam;
    }

    public void setFinalExam(double finalExam) {
        this.finalExam = finalExam;
    }
}
