/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class StudentOperations extends ArrayList<Student> {
        public StudentOperations() {
        super();

    }

    public void addStudent() {
        String id;
        do {
            id = Vali.pattenString("Input ID (HE[0-9]{6}):" , "HE[0-9]{6}");
            if (isExist(id) != null) System.out.println("ID already exists");
        } while (isExist(id) != null);
        this.add(new Student(id, Vali.nonBlankStr("Full Name ?"), Vali.inputYN("Sex? (y/Y for male, n/N for female)")? "Male" : "Female"
                , Vali.nextDouble("Progress Test ?", 0,10), Vali.nextDouble("Assignment?", 0,10)
                , Vali.nextDouble("Workshop?", 0,10), Vali.nextDouble("Practical Exam?", 0,10)
                , Vali.nextDouble("Final Exam?", 0,10)));
    }

    public void addMultiple()
    {
        int n = Vali.nextInt("How many students to add?", 1, 100);
        for(int i = 0; i < n; i++)
        {
            System.out.println("Student number : " + (i + 1) );
            addStudent();
        }
    }

    public void printList()
    {
        System.out.format("||%8s||%-30s||%6s||%-5s||%-5s||%-5s||%-5s||%-5s||\n", "ID", "Full Name", "Sex", "PT", "Ass", "WS", "PE", "FE");
        this.forEach((student) -> {
            System.out.println(student);
            });
    }

    public void findID()
    {
        String id = Vali.pattenString("Input ID (HE[0-9]{6}):" , "HE[0-9]{6}");
        Student student = isExist(id);
        if(student == null) System.out.println("Student does not Exist");
        else {
            System.out.println("Found student");
            System.out.format("||%8s||%-30s||%6s||%-5s||%-5s||%-5s||%-5s||%-5s||\n", "ID", "Full Name", "Sex", "PT", "Ass", "WS", "PE", "FE");
            System.out.println(student);
        }
    }

    public void printResults()
    {
        System.out.format("||%8s||%-30s||%6s||%20s||\n", "ID", "Full Name", "Sex", "Average Marks");
        this.forEach((student) -> {
            System.out.println(student.toStringResult());
            });
    }

    public void printPassed()
    {
        System.out.format("||%8s||%-30s||%6s||%20s||\n", "ID", "Full Name", "Sex", "Status");
        this.forEach((student) -> {
            System.out.println(student.toStringPassed());
            });
    }

    public void deleteID()
    {
        String id = Vali.pattenString("Input ID (HE[0-9]{6}):" , "HE[0-9]{6}");
        Student student = isExist(id);
        if(student == null) System.out.println("Student does not Exist");
        else {
            this.remove(student);
            System.out.println("Removed student");
        }
    }

    private Student isExist(String id) {
        for(Student student : this)
        {
            if (student.getId().equals(id))
                return student;
        }
        return null;
    }

    public void toFile()
    {
        BufferedWriter buff = null;
        try {
            FileWriter writer = new FileWriter("result.txt");
            buff = new BufferedWriter(writer);
            for(Student student : this)
            {
                buff.append(student.toString());
                buff.append('\n');
            }
            System.out.println("Written to result.txt");
        } catch (IOException e) {
        } finally {
            try{
                if(!(buff == null)) buff.close();
            }catch (IOException e)
            {
            }

        }
    }
}
