/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes.Com;

/**
 *
 * @author Admin
 */
public class Brand {
    private String brandID;
    private String brandName;
    private String soundBrand;
    private double price;
    
    /**
     * Constructor
     */
    public Brand(){}
    
    /**
     * Constructor
     * @param brandID id string
     * @param brandName name string
     * @param soundBrand sound string 
     * @param price price value
     */
    public Brand(String brandID, String brandName, String soundBrand, double price)
    {
        this.brandID = brandID; 
        this.brandName = brandName; 
        this.soundBrand = soundBrand; 
        this.price = price;
    }
    
    //getter\setters
    public String getBrandID()
    {return brandID;}
    public void setBrandID(String brandID)
    {this.brandID = brandID;}
    public String getBrandName()
    {return brandName;}
    public void setBrandName(String brandName)
    {this.brandName = brandName;}
    public String getSoundBrand()
    {return soundBrand;}
    public void setSoundBrand(String soundBrand)
    {this.soundBrand = soundBrand;}
    public double getPrice()
    {return price;}
    public void setPrice(double price)
    {this.price = price;}
    
    /**
     *
     * @return a detailed info about a string
     */
    @Override
    public String toString()
    {return brandID + ", " + brandName + ", " + soundBrand + ": " + price;}
}
