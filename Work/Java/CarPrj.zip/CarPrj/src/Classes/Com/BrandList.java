/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes.Com;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class BrandList extends ArrayList<Brand>{
    
    /**
     * constructor
     */
    public BrandList ()
    {
        super();
    }
    
    /**
     * Load data from file
     * @param filename fileName to load
     */
    public void loadFromFile(String filename)
    {
        String bufferstring;
        File file = new File(filename);
        String split[];
        try
        {
            
            FileReader fr;
            fr = new FileReader(file);
            BufferedReader br;
            br = new BufferedReader(fr);
            while((bufferstring = br.readLine()) != null)
            {
                split = bufferstring.split("[:,]");
                Brand bufBrand = new Brand(split[0].trim(), split[1].trim(), split[2].trim(), Double.parseDouble(split[3]));
                this.add(bufBrand);
            }
            br.close();
            fr.close();
        } catch (IOException e)
        {
            System.out.println(e.getMessage());
        }
    }
    
    /**
     * Save data to file
     * @param filename file to save
     * @return true if success, false otherwise
     */
    public boolean saveToFile(String filename)
    {
        File file = new File(filename);
        if (!file.exists()) return false;
        try
        {
            
            FileWriter fw;
            fw = new FileWriter(file);
            BufferedWriter bw;
            bw = new BufferedWriter(fw);
            for(Brand brand : this)
            {
                bw.write(brand.toString() + "\n");
            }
            bw.close();
            fw.close();
        }  catch (IOException e)
        {
            System.out.println(e.getMessage());
        }
        return true;
    }
    
    /**
     * Search brand by id
     * @param bID id string to search
     * @return index of brand
     */
    public int searchID (String bID)
    {
        for(int i  = 0; i < this.size(); i++)
        {
            if(this.get(i).getBrandID().equals(bID))
            {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * let user choose a brand form the brandList
     * @return choosed brand
     */
    public Brand getUserChoice()
    {
        Menu<Brand> menu = new Menu<>();
        return menu.ref_getChoice(this);
    }
    
    /**
     * Add a new brand
     */
    public void addBrand()
    {   
        Inputter ip = new Inputter();
        String ID;
        boolean found;
        do
        {
            found = true;
            ID  = ip.inputNonBlankStr("Enter brand ID");
            for(Brand brand : this)
            {
                if(brand.getBrandID().equals(ID))
                {
                    found = false;
                    System.out.println("Brand already exist. Try again.");
                }
            }
        } while(!found);
        String name = ip.inputNonBlankStr("Enter brand name");
        String sound = ip.inputNonBlankStr("Enter sound brand name");
        double price = ip.inputDouble("Enter price", 0 , 10000000);
        this.add(new Brand(ID, name, sound, price));
    }
    
    /**
     * List all brand
     */
    public void listBrand()
    {
        for(Brand brand : this) {
            System.out.println(brand);
        }
    }
    
    /**
     * update all information about a brand
     */
    public void updateBrand()
    {
        Inputter ip = new Inputter();
        int found;
        do
        {
            found = searchID(ip.inputNonBlankStr("Enter brand ID"));
            if(found == -1) System.out.println("Brand not found");
            else System.out.println("Found brand");
        } while(found == -1);
        String name = ip.inputNonBlankStr("Enter brand name");
        String sound = ip.inputNonBlankStr("Enter sound brand name");
        double price = ip.inputDouble("Enter price", 0 , 10000000);
        this.set(found, new Brand(this.get(found).getBrandID(), name, sound, price));
    }
}
