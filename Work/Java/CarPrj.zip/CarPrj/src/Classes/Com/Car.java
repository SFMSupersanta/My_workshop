
package Classes.Com;


public class Car implements Comparable<Car>{
    private String carID;
    private String color;
    private String frameID;
    private String engineID;
    private Brand brand;
    
    /**
     * Constructor
     */
    public Car(){}
    
    /**
     * Constructor
     * @param carID car's id
     * @param brand Brand object
     * @param color color string
     * @param frameID frame id string
     * @param engineID engine id string
     */
    public Car(String carID, Brand brand, String color, String frameID, String engineID)
    {
        this.carID = carID;
        this.brand = brand;
        this.color = color;
        this.frameID = frameID;
        this.engineID = engineID;
    }
    
    /**
     * get a string of information
     * @return detailed information about a car
     */
    public String screenString()
    {
        return brand.getBrandID() + "\n" + carID + ", " + color + ", " + frameID + ", " + engineID;
    }
    
    //getters\setters
    public String getCarID() { return carID; }
    public String getColor() { return color; }
    public String getFrameID() { return frameID; }
    public String getEngineID() { return engineID; }
    public Brand getBrand() { return brand; }
    public void setBrand(Brand brand) { this.brand = brand; }
    public void setColor(String color) { this.color = color; }
    public void setFrameID(String frameID) { this.frameID = frameID;}
    public void setCarID(String carID) {this.carID = carID;}
    public void setEngineID(String engineID) {this.engineID = engineID;}
    
    /**
     * 
     * @return a detailed string about a car for printing
     */
    @Override
    public String  toString()
    { return carID + ", " + brand.getBrandID() + ", " + color + ", " + frameID + ", " + engineID;}
   
    /**
     * used for sorting in ArrayList
     * @param car to compare
     * @return compared value
     */
    @Override
    public int compareTo(Car car) {
        int d = this.brand.getBrandName().compareTo(car.brand.getBrandName());
        if (d != 0) return d;
        else return this.carID.compareTo(car.getCarID());
    }
}
