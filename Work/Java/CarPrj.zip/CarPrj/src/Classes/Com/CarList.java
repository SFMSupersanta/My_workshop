/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes.Com;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Admin
 */
public class CarList extends ArrayList<Car>{

    private BrandList brandlist = new BrandList();
    private final Menu<Brand> brandip = new Menu<>();
    Inputter ip = new Inputter();
    
    /**
     * Constructor
     * @param brandlist brandList to add into the instance
     */
    public CarList(BrandList brandlist) 
    {
        super();
        this.brandlist = brandlist;
    }
    
    /**
     * Delete a car, ID is typed in by user
     */
    public void removeID()
    {
        int index;
        do
        {
            index = searchID(ip.inputNonBlankStr("Input carID"));
            if(index == -1) System.out.println("Can't find car");
        } while(index == -1);

        this.remove(index);
    }
    
    /**
     * Update a car
     */
    public void updateCar()
    {
        int index;
        do
        {
            index = searchID(ip.inputNonBlankStr("Input carID"));
            if(index == -1) System.out.println("Can't find car");
        } while(index == -1);

        this.remove(index);
        String engineID;
        boolean found;
        do
        {    
            found = true;
            engineID = ip.inputPatten("Enter engineID (E00000)", "E[0-9]{5}");
            for(Car brand : this)
            {
                if(brand.getEngineID().equals(engineID))
                {
                    found = false;
                    System.out.println("EngineID already exist. Try again.");
                }
            }
        }while (!found);
        this.set(index, new Car(this.get(index).getCarID(), brandip.ref_getChoice(brandlist), ip.inputNonBlankStr("Enter color"), ip.inputPatten("Enter frame id (F0000)","F[0-9]{5}"), engineID));
    }
    
    /**
     * Load cars from file, add BrandList object into Car object before adding into this
     * @param filename filename to load
     * @return true if success, false otherwise
     */
    public boolean loadFromFile(String filename)
    {
        File file = new File(filename);
        if(!file.exists()) return false;
        String buffer;
        try
        {
            FileReader fr;
            fr = new FileReader(file);
            BufferedReader br;
            br = new BufferedReader(fr);
            while ((buffer = br.readLine()) != null)
            {
                String[] slice = buffer.split(",");
                int index = brandlist.searchID(slice[1].trim());
                this.add(new Car(slice[0].trim(), brandlist.get(index), slice[2].trim(), slice[3].trim(), slice[4].trim()));
            }
            br.close();
            fr.close();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
        return true;
    }
    
    /**
     * List cars in accending order
     */
    public void listCar()
    {
        Collections.sort(this);
        for(Car e : this)
        {
            System.out.println(e);
        }
    }
    
    /**
     * save existing cars into a file
     * @param filename filename to save in
     * @return true if success, false otherwise
     */
    public boolean saveToFile(String filename)
    {
        File file = new File(filename);
        if(!file.exists()) return false;
        try
        {
            try (FileWriter fw = new FileWriter(file); BufferedWriter bw = new BufferedWriter(fw)) {
                for(Car e: this)
                {
                    bw.write(e + "\n");
                }
            }
        }catch(IOException e)
        {
            System.out.println(e.getMessage());
        }
        return true;
    }
    
    /**
     * get position of a car form id
     * @param carID ID string to search
     * @return id position
     */
    public int searchID (String carID)
    {
        int i;
        for(i = 0; i < this.size(); i++)
        {    
            if(this.get(i).getCarID().trim().equals(carID))
            return i;
        }
        return -1;
    }
    
    /**
     * get position of a car form frame id
     * @param fID frame id string to search
     * @return id position
     */
    public int searchFrame (String fID)
    {
        int i;
        for(i = 0; i < this.size(); i++)
        {    
            if(this.get(i).getFrameID().trim().equals(fID))
            return i;
        }
        return -1;
    }
    
    /**
     * get position of a car form engine id
     * @param eID engine id
     * @return id position
     */
    public int searchEngine (String eID)
    {
        int i;
        for(i = 0; i < this.size(); i++)
        {    
            if(this.get(i).getEngineID().trim().equals(eID))
            return i;
        }
        return -1;
    }
    
    /**
     * add a car
     */
    public void addCar()
    {
        String ID;
        boolean found;
        do
        {
            found = true;
            ID  = ip.inputNonBlankStr("Enter car ID");
            for(Car brand : this)
            {
                if(brand.getCarID().equals(ID))
                {
                    found = false;
                    System.out.println("ID already exist. Try again.");
                }
            }
        } while(!found);
        String engineID;
        do
        {    
            found = true;
            engineID = ip.inputPatten("Enter engineID (E00000)", "E[0-9]{5}");
            for(Car brand : this)
            {
                if(brand.getEngineID().equals(engineID))
                {
                    found = false;
                    System.out.println("EngineID already exist. Try again.");
                }
            }
        }while (!found);
        this.add(new Car(ID, brandip.ref_getChoice(brandlist), ip.inputNonBlankStr("Enter color"), ip.inputPatten("Enter frame id (F0000)","F[0-9]{5}"), engineID));
    }
    
    /**
     * find a car by brandname
     */
    public void printBasedBrandName ()
    {
        String search = ip.inputNonBlankStr("Enter part of brand name");
        int i = 0;
        for(Car car : this)
        { 
            if(car.getBrand().getBrandID().contains(search)) System.out.println(car.screenString());
            i += 1;
        }
        if(i == 0) System.out.println("No car found");
    }
}
