/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes.Com;


import java.util.ArrayList;
import java.util.Scanner;

/**
 * Menu class for printing and get user's choice
 * @author Admin
 * @param <E>
 */
public class Menu <E>{
    private static final java.util.Scanner scan = new Scanner(System.in);
    
    /**
     * get choice from user by predefined ArrayList of choices
     * @param options ArrayList of objects for options
     * @return choice from user
     */
    public int int_getChoice(ArrayList<E> options)	
    {
        int size = 0;
        
        for(E thing : options)
        {
            System.out.println(size+1 + " " + thing);
            size += 1;
        }
        System.out.printf("Please choose an option 1..%d\n", options.size());
        int choice;
        do
        {
            while(!scan.hasNextInt())
            {
                System.out.println("Not a valid choice");
                scan.nextLine();
            }
            choice =  scan.nextInt();
            if(choice < 1 || choice > options.size()) System.out.println("Out of range");
        } while(choice < 1 || choice > options.size());
        return choice;
    }
    
    /**
     * get choice from user by predefined ArrayList of choices
     * @param options ArrayList of objects for options
     * @return object choosed from user
     */
    public E ref_getChoice(ArrayList<E> options)
    {
        int choice = int_getChoice(options);
        return options.get(choice - 1);
    }
}
