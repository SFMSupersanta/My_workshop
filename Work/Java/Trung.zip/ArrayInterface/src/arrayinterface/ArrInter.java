/**
 *
 * @author os
 */
package arrayinterface;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

class ArrInter implements arrayMethod {

    static ArrayList<Integer> arr = new ArrayList<>();

    @Override
    public void arrayAdd() {
        System.out.print("Type the value to add: ");
        arr.add(ValidatorMethod.getInt());
    }

    @Override
    public void arrayRemove(int element) {
        arr.remove(element);
    }

    @Override
    public void arrayUpdate(int element) {
        System.out.println("Value to change: ");
        arr.set(element, ValidatorMethod.getInt());
    }

    @Override
    public void arrayPrint() {
        System.out.println("Your array: " + Arrays.toString(arr.toArray()));
    }

    @Override
    public void arrayFind() {
        System.out.println("Value to find: ");
        int find = ValidatorMethod.getInt();
        boolean found = false;
        for(int i : arr)
        {
            if(i == find) 
            {
                System.out.println("Found " + find + " at index of " + arr.indexOf(i));
                found = true;
            }    
            if(!found) System.out.println("Can't find value " + find);

        }
    }

    @Override
    public void arraySort() {
        Collections.sort(arr);
    }
    
}

