/**
 *
 * @author os
 */
package arrayinterface;



public class ArrayInterface {
    
    
    public static void main(String[] args) {
        int choice;
        ArrInter arr = new ArrInter();
        do
        {
            System.out.println("\n- - - - - Array Interface - - - - - ");
            System.out.println("[1] Add element(s) into the array.");
            System.out.println("[2] Remove a specified element from the array.");
            System.out.println("[3] Update an element to a new value.");
            System.out.println("[4] Sort the array.");
            System.out.println("[5] Find an element in the array.");
            System.out.println("[6] Print out the array.");
            System.out.println("[0] Exit\nYour choice: ");
            
            choice = ValidatorMethod.getInt();
            switch (choice){
                //Case 1:
                case 1:
                    arr.arrayAdd();
                break;

                //Case 2:
                case 2:
                    System.out.print("Index to remove: ");
                    arr.arrayRemove(ValidatorMethod.getInt());
                break;

                //Case 3:
                case 3:
                    System.out.print("Index to update:");
                    arr.arrayUpdate(ValidatorMethod.getInt());
                break;

                // Case 4
                case 4:
                    System.out.println("Array sorted");
                    arr.arraySort();
                break;

                //Case 5:
                case 5:
                    arr.arrayFind();

                break;

                //Case 6:
                case 6:
                    arr.arrayPrint();
                break;

                //Case 0:
                case 0:
                    System.out.println("Shutting down successfully...");
                break; 

                default:
                    System.out.println("Wrong option. Type again.");
                    break;
            }
        } while(choice != 0);
        
    }
}
