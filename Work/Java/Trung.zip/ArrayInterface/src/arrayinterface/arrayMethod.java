/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayinterface;

/**
 *
 * @author os
 */

interface arrayMethod{
    public void arrayAdd();
    public void arrayRemove(int element);
    public void arrayUpdate(int element);
    public void arrayPrint();
    public void arrayFind();
    public void arraySort();
}